plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("kotlin-kapt") // ✅ Required for Room Database
}

android {
    namespace = "com.example.securenotesx"
    compileSdk = 36 // ✅ Updated to Android API 36

    defaultConfig {
        applicationId = "com.example.securenotesx"
        minSdk = 23
        targetSdk = 36 // ✅ Target latest API 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17 // ✅ Required for API 36
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17" // ✅ Required for API 36
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    // ✅ Core Android dependencies
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // ✅ Jetpack Compose Navigation (Required for API 36)
    implementation("androidx.navigation:navigation-compose:2.8.9")

    // ✅ Room Database dependencies (Updated for API 36)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // ✅ Biometric Authentication (Updated for API 36)
    implementation("androidx.biometric:biometric:1.2.0-alpha05")

    // ✅ Cryptography Library for AES Encryption
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // ✅ Testing dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}