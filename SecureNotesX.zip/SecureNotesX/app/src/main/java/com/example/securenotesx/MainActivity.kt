package com.example.securenotesx

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.*
import com.example.securenotesx.ui.theme.SecureNotesXTheme
import com.example.securenotesx.utils.BiometricHelper
import com.example.securenotesx.utils.PinAuthScreen

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SecureNotesXTheme {
                AppNavigator()
            }
        }
    }
}

@Composable
fun AppNavigator() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "auth_screen") {
        composable("auth_screen") {
            AuthScreen(navController)
        }
        composable("notes_screen") {
            NotesScreen()
        }
    }
}

@Composable
fun AuthScreen(navController: NavController) {
    val activity = LocalContext.current as? FragmentActivity

    var showPinAuth by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        activity?.let {
            BiometricHelper.authenticate(
                activity = it,
                onSuccess = { navController.navigate("notes_screen") },
                onFailure = { showPinAuth = true }
            )
        } ?: run { showPinAuth = true }
    }

    if (showPinAuth) {
        PinAuthScreen(navController)
    }
}

@Composable
fun NotesScreen() {
    var notes by remember { mutableStateOf(mutableListOf<String>()) }
    var newNote by remember { mutableStateOf("") }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (newNote.isNotEmpty()) {
                        notes = (notes + newNote).toMutableList()
                        newNote = ""
                    }
                },
                containerColor = Color.Blue,
                modifier = Modifier.size(70.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Note", tint = Color.White)
            }
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFEEEEEE))
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = newNote,
                    onValueChange = { newNote = it },
                    label = { Text("Enter your note") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(notes) { note ->
                        NoteItem(note, onDelete = {
                            notes = notes.filter { it != note }.toMutableList()
                        })
                    }
                }
            }
        }
    )
}

@Composable
fun NoteItem(note: String, onDelete: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = note,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete Note", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NotesScreenPreview() {
    SecureNotesXTheme {
        NotesScreen()
    }
}
