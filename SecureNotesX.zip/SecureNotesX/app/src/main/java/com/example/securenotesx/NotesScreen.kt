package com.example.securenotesx

import android.app.Application
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.securenotesx.database.NoteViewModel
import com.example.securenotesx.database.NoteViewModelFactory
import com.example.securenotesx.utils.CryptoUtils

@Composable
fun NotesScreen(viewModel: NoteViewModel = viewModel(factory = NoteViewModelFactory(LocalContext.current.applicationContext as Application))) {
    val context = LocalContext.current
    var noteText by remember { mutableStateOf("") }
    val notes by viewModel.notes.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "Secure Notes", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = noteText,
            onValueChange = { noteText = it },
            label = { Text("Write a secure note...") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (noteText.isNotEmpty()) {
                    viewModel.addNote(noteText)
                    noteText = ""
                    Toast.makeText(context, "Note Saved!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Save Note")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(notes) { note ->
                val decryptedText = CryptoUtils.decrypt(note.encryptedText, note.iv)

                Card(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = decryptedText, modifier = Modifier.weight(1f))

                        IconButton(
                            onClick = {
                                viewModel.deleteNote(note.id)
                                Toast.makeText(context, "Note Deleted", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Note")
                        }
                    }
                }
            }
        }
    }
}