package com.example.securenotesx.database

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.securenotesx.utils.CryptoUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NoteDatabase.getDatabase(application).noteDao()

    val notes: StateFlow<List<Note>> = db.getNotes().stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        emptyList()
    )

    fun addNote(text: String) {
        viewModelScope.launch {
            val (encryptedText, iv) = CryptoUtils.encrypt(text)
            val note = Note(encryptedText = encryptedText, iv = iv)
            db.insert(note)
        }
    }

    fun deleteNote(noteId: Int) {
        viewModelScope.launch {
            db.deleteNote(noteId)
        }
    }
}