package com.example.securenotesx.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(note: Note): Long // ✅ Removed suspend to fix Room error

    @Query("SELECT * FROM notes ORDER BY id DESC")
    fun getNotes(): Flow<List<Note>> // ✅ Uses Flow for real-time UI updates

    @Query("DELETE FROM notes WHERE id = :noteId")
    fun deleteNote(noteId: Int): Int // ✅ Removed suspend to prevent return type issues
}